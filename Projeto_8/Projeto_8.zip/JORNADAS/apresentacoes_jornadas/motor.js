/* AdvogadoJá · Módulo independente · execução local sem dependência externa */
(()=>{'use strict';
if(new URLSearchParams(location.search).has('embed'))document.body.classList.add('embedded');
const IN_WORKSPACE=new URLSearchParams(location.search).get('workspace')==='1';
const $=s=>document.querySelector(s), app=$('#app'), S={bundle:null,screen:null,mode:'campos',query:'',journey:null,subjourney:null,device:'mobile',scenario:null,roteiro:null,step:0,history:[],modal:null,changes:0,bankView:'campos',branchChoices:{},showCount:24};
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const dt=v=>Array.isArray(v)?v:[];
const idEsc=v=>esc(v).replace(/`/g,'');
const scr=()=>S.bundle?.telas||{}, screenIDs=()=>Object.keys(scr()).sort(), current=()=>scr()[S.screen]||null;
const tOf=id=>scr()[id]?.tela||{};
const nameOf=id=>tOf(id).identidade?.nomeExibicao||tOf(id).identidade?.nome||id;
const moduleName=()=>({BANCO:'Banco',FLUXO:'Fluxo',JORNADAS:'Jornadas',PROTOTIPO:'Protótipo'})[MODULO]||MODULO;
const make=(tag,cls='',html='')=>{const el=document.createElement(tag);if(cls)el.className=cls;el.innerHTML=html;return el};
const pathFor=o=>Object.entries(o||{}).filter(([_,v])=>v!=null).map(([k,v])=>`${k}: ${typeof v==='object'?JSON.stringify(v).slice(0,85):String(v).slice(0,85)}`).join(' · ');
const jIndex=()=>{
 const m=new Map();for(const id of screenIDs())for(const p of dt(tOf(id).classificacao?.jornadas)){
  const j=p.jornada||{},sj=p.subjornada||{};if(!j.id)continue;
  if(!m.has(j.id))m.set(j.id,{id:j.id,name:j.nome||j.id,order:j.ordem??999,subs:new Map()});
  const group=m.get(j.id),sk=sj.id||'_sem_subjornada';if(!group.subs.has(sk))group.subs.set(sk,{id:sk,name:sj.nome||'Sem subjornada',order:sj.ordem??999,items:[]});
  group.subs.get(sk).items.push({id,p,order:p.ordemTela??999});
 }
 return [...m.values()].sort((a,b)=>a.order-b.order||a.name.localeCompare(b.name));
};
function nav(){const all=screenIDs();const journey=jIndex(),rotes=dt(S.bundle?.simulacoes?.jornadasSimuladas);let children=[];
 if(MODULO==='JORNADAS')children=[{key:'campos',label:'Campos utilizados',ico:'≡'},{key:'visualizacao',label:'Visualização de jornadas',ico:'▦',sub:journey.map(j=>({key:'journey:'+j.id,label:j.name,count:[...j.subs.values()].reduce((n,x)=>n+x.items.length,0)}))}];
 if(MODULO==='FLUXO')children=[{key:'campos',label:'Campos utilizados',ico:'≡'},{key:'visualizacao',label:'Visualização do fluxo',ico:'⌁'}];
 if(MODULO==='BANCO')children=[{key:'campos',label:'Campos utilizados',ico:'≡'},{key:'modelagem',label:'Modelagem do banco',ico:'▤',sub:[{key:'banco:campos',label:'Campos por tela'},{key:'banco:tabelas',label:'Entidades e tabelas'},{key:'banco:operacoes',label:'Operações declaradas'}]}];
 if(MODULO==='PROTOTIPO')children=[{key:'campos',label:'Campos utilizados',ico:'≡'},{key:'simulador',label:'Protótipo interativo',ico:'▶',sub:[{key:'proto:livre',label:'Navegação livre'},{key:'proto:roteiros',label:'Apresentação de jornadas',sub:rotes.map(j=>({key:'roteiro:'+j.id,label:j.name}))}]}];
 return `<div class="nav-caption">MÓDULO</div><div class="nav-title">${esc(moduleName())}</div><div class="nav-hint">${all.length} telas no snapshot independente</div><div class="nav-tree">${children.map(navItem).join('')}</div><div class="side-note"><b>Dados locais</b><span>Este módulo usa exclusivamente seu próprio <code>documento.json</code>.</span></div>`;
 function navItem(item,level=0){const active=S.mode===item.key||(item.key==='visualizacao'&&S.mode.startsWith('journey:'))||(item.key==='simulador'&&['proto:livre','proto:roteiros'].includes(S.mode))||(item.key==='modelagem'&&S.mode.startsWith('banco:'));
 return `<div class="nav-item-wrap" style="--level:${level}"><button type="button" data-nav="${esc(item.key)}" class="nav-item ${active?'active':''}"><span class="nav-ico">${esc(item.ico||'·')}</span><span class="nav-label">${esc(item.label)}</span>${item.count!=null?`<span class="pill">${item.count}</span>`:''}</button>${item.sub?`<div class="nav-sub">${item.sub.map(x=>navItem(x,level+1)).join('')}</div>`:''}</div>`}
}
function header(){return `<div class="head-left"><button class="menu-toggle" title="Abrir menu" data-action="toggleSidebar">☰</button><span class="brand-mark">AJ</span><div class="head-brand"><b>AdvogadoJá</b><small>WORKSPACE · MÓDULO AUTÔNOMO</small></div></div><div class="head-actions"><span id="saveStatus" class="save-status">${S.changes?'Alterações não exportadas':'Snapshot local'}</span><button class="head-btn" data-action="import">Importar JSON</button><button class="head-btn primary" data-action="export">Exportar JSON</button></div>`}
function topTitle(){const label=S.mode.startsWith('journey:')?`Jornada · ${jIndex().find(j=>j.id===S.mode.slice(8))?.name||S.mode.slice(8)}`:S.mode.startsWith('roteiro:')?`Roteiro · ${dt(S.bundle?.simulacoes?.jornadasSimuladas).find(j=>j.id===S.mode.slice(8))?.name||''}`:S.mode.startsWith('banco:')?'Modelagem do banco':S.mode==='campos'?'Campos utilizados':S.mode==='visualizacao'?'Visualização do fluxo':S.mode==='simulador'?'Protótipo interativo':S.mode==='modelagem'?'Modelagem do banco':S.mode.startsWith('proto:')?'Protótipo interativo':'Área de trabalho';return `<div class="intro"><div><span class="kicker">${esc(moduleName())} / ${esc(label)}</span><h1>${esc(label)}</h1><p>${S.mode==='campos'?'Inspeção documental dos campos efetivamente presentes no JSON do módulo.':S.mode.startsWith('banco:')||S.mode==='modelagem'?'Entidades e operações só são efetivas quando declaradas; campos visuais são candidatos.':S.mode.startsWith('journey:')||MODULO==='JORNADAS'?'Telas organizadas por participações explícitas de jornadas.':S.mode==='visualizacao'?'Relações declaradas, bifurcações e prévias; sem criar destinos automaticamente.':'Simulação local, sem acesso a serviços externos ou persistência de produção.'}</p></div><div class="chip">${screenIDs().length} telas</div></div>`}
function shell(){app.innerHTML=`<header id="topbar">${header()}</header><div class="work"><aside id="sidebar">${nav()}</aside><main id="main">${topTitle()}<section id="pane"></section></main></div><input id="fileLoader" type="file" accept=".json,application/json" hidden>`;
 if(IN_WORKSPACE){
  // Só o conteúdo e as AÇÕES permanecem visíveis; o menu agora vive no index geral.
  const toolbar=make('div','workspace-module-actions');
  const buttons=$('#topbar .head-actions');if(buttons)toolbar.append(buttons);
  $('#main').insertBefore(toolbar,$('#main').firstChild);
 }
 renderPane();
 publishJornadas();
 if(IN_WORKSPACE&&window.parent!==window){
  const walk=el=>{const button=el.querySelector(':scope > button[data-nav]');if(!button)return null;
   const sub=el.querySelector(':scope > .nav-sub');const children=sub?[...sub.children].map(walk).filter(Boolean):[];
   return {id:button.dataset.nav,label:button.querySelector('.nav-label')?.textContent?.trim()||button.textContent.trim(),kind:'mode',...(children.length?{children}:{})};};
  const menu=[...document.querySelectorAll('#sidebar .nav-tree > .nav-item-wrap')].map(walk).filter(Boolean);
  window.parent.postMessage({type:'aj.workspace.module-state',module:MODULO,mode:S.mode,menu},location.origin);
 }
}
function setMode(mode){if(mode==='simulador')mode='proto:livre';if(mode==='modelagem')mode='banco:campos';if(mode==='proto:roteiros')mode='roteiro:'+(dt(S.bundle?.simulacoes?.jornadasSimuladas)[0]?.id||'');if(mode.startsWith('banco:'))S.bankView=mode.slice(6);if(mode.startsWith('journey:')){S.journey=mode.slice(8);S.subjourney=null;S.showCount=24}if(mode.startsWith('roteiro:')){S.roteiro=mode.slice(8);S.step=0;S.branchChoices={}}S.mode=mode;shell();}
function renderPane(){const pane=$('#pane');if(!pane)return;
 if(S.mode==='campos'){pane.innerHTML=fieldsView();return}
 if(MODULO==='JORNADAS')pane.innerHTML=journeysView();
 else if(MODULO==='FLUXO')pane.innerHTML=flowView();
 else if(MODULO==='BANCO')pane.innerHTML=bankView();
 else pane.innerHTML=prototypeView();
 injectFrames(pane);
}
function screensSelect(selected=S.screen,selId='screenSelect'){return `<select id="${selId}" aria-label="Tela">${screenIDs().map(id=>`<option value="${esc(id)}" ${id===selected?'selected':''}>${esc(nameOf(id))} · ${esc(id)}</option>`).join('')}</select>`}
function fieldsView(){const id=S.screen||screenIDs()[0],t=tOf(id),keys=Object.keys(t);const focus=MODULO==='FLUXO'?['identidade','classificacao','navegacao','estados','acoes','interacoes']:MODULO==='BANCO'?['identidade','classificacao','dados','acoes','interacoes','componentes']:MODULO==='JORNADAS'?['identidade','classificacao','estrutura','componentes','navegacao']:['identidade','estados','acoes','navegacao','interacoes','mocks','dados'];
 const ordered=[...new Set([...focus,...keys])];return `<div class="toolbar"><label>Tela ${screensSelect(id)}</label><label>Buscar campo <input id="fieldSearch" placeholder="Ex.: navegacao, dados, mocks" value="${esc(S.query)}" /></label><button data-action="showJson">JSON integral da tela</button></div><div class="notice">Os blocos destacados são prioritários para este módulo. A exibição não altera o contrato.</div><div class="field-grid">${ordered.filter(k=>!S.query||k.toLowerCase().includes(S.query.toLowerCase())).map(k=>`<details class="field-card" ${focus.includes(k)?'open':''}><summary><span>${esc(k)}</span><small>${esc(typeof t[k]==='object'?Array.isArray(t[k])?t[k].length+' itens':Object.keys(t[k]||{}).length+' grupos':'valor')}</small></summary><pre>${esc(JSON.stringify(t[k]??null,null,2))}</pre></details>`).join('')}</div>`}
function findJourney(id){return jIndex().find(j=>j.id===id)||jIndex()[0]}
function journeyItems(j,sub){if(!j)return[];return [...j.subs.values()].filter(s=>!sub||sub===s.id).sort((a,b)=>a.order-b.order).flatMap(s=>s.items.sort((a,b)=>a.order-b.order).map(i=>({...i,sub:s.name}))) }
function journeysView(){const j=findJourney(S.journey);if(!j)return `<div class="empty">Nenhuma jornada classificada nos contratos.</div>`;S.journey=j.id;
 const options=[...j.subs.values()].sort((a,b)=>a.order-b.order);const items=journeyItems(j,S.subjourney).filter(x=>!S.query||nameOf(x.id).toLowerCase().includes(S.query.toLowerCase())||x.id.includes(S.query.toLowerCase()));
 const show=items.slice(0,S.showCount);return `<div class="toolbar"><label>Jornada <select id="journeySelect">${jIndex().map(x=>`<option value="${esc(x.id)}" ${x.id===j.id?'selected':''}>${esc(x.name)}</option>`).join('')}</select></label><label>Subjornada <select id="subjourneySelect"><option value="">Todas</option>${options.map(x=>`<option value="${esc(x.id)}" ${x.id===S.subjourney?'selected':''}>${esc(x.name)}</option>`).join('')}</select></label><label>Dispositivo <select id="deviceSelect"><option value="mobile" ${S.device==='mobile'?'selected':''}>Mobile</option><option value="desktop" ${S.device==='desktop'?'selected':''}>Desktop</option></select></label><label>Buscar <input id="journeySearch" value="${esc(S.query)}" placeholder="Nome ou ID"></label><button data-action="addToJourney">Adicionar tela à jornada</button><button data-action="newJourney">Nova jornada</button></div><p class="mini">${items.length} participações encontradas. A ordem é a declarada no JSON, não uma ligação de fluxo presumida.</p><div class="gallery">${show.map(({id,sub,order},i)=>`<article class="screen-card"><div class="screen-card-head"><span>${String(order).padStart(2,'0')} · ${esc(sub)}</span><button data-preview="${esc(id)}" class="text-button">Detalhes</button></div><div class="frame-mini ${S.device}"><iframe class="screen-iframe" sandbox="allow-scripts" data-screen="${esc(id)}" loading="lazy" title="Prévia ${esc(nameOf(id))}"></iframe><button class="cover-button" data-preview="${esc(id)}" title="Abrir prévia da tela"></button></div><div class="screen-card-foot"><strong>${esc(nameOf(id))}</strong><code>${esc(id)}</code></div></article>`).join('')}</div>${items.length>S.showCount?`<div class="load-more"><button data-action="moreScreens">Mostrar mais telas (${items.length-S.showCount})</button></div>`:''}`;
}
function getRels(id){return dt(tOf(id).navegacao?.relacoes).filter(r=>r&&typeof r==='object')}
function relTarget(r){const d=r.destino;return typeof d==='string'?d:d?.ref||d?.telaRef||''}
function relType(r){return r.destino?.tipo||r.destinoTipo||'não definido'}
function flowView(){if(!S.screen)S.screen=screenIDs()[0];const rs=getRels(S.screen),inbound=[];
 for(const id of screenIDs())if(id!==S.screen)for(const r of getRels(id))if(relTarget(r)===S.screen)inbound.push({id,r});
 return `<div class="toolbar"><label>Tela de origem ${screensSelect()}</label><button data-action="addRelation">+ Conectar tela</button><label>Dispositivo <select id="deviceSelect"><option value="mobile" ${S.device==='mobile'?'selected':''}>Mobile</option><option value="desktop" ${S.device==='desktop'?'selected':''}>Desktop</option></select></label></div><div class="split"><div><div class="diagram"><div class="node focus"><div class="node-type">TELA DE ORIGEM</div><b>${esc(nameOf(S.screen))}</b><code>${esc(S.screen)}</code><button data-preview="${esc(S.screen)}">Abrir prévia</button></div>${rs.length?`<div class="connector">↓ ${rs.length} relações declaradas</div>`:'<div class="connector">↓ Sem saídas declaradas</div>'}<div class="branches">${rs.map(r=>`<div class="node"><span class="node-type">${esc(r.tipo||'relação')} · ${esc(relType(r))}</span><b>${esc(r.rotulo||r.opcao||r.id)}</b><small>${esc(r.descricao||'')}</small><code>${esc(relTarget(r)||'destino não declarado')}</code>${scr()[relTarget(r)]?`<button data-go="${esc(relTarget(r))}">Examinar destino</button>`:''}${r.condicaoRef?`<span class="condition">Condição: ${esc(r.condicaoRef)}</span>`:''}</div>`).join('')||'<div class="node pending">Sem conexões de saída; inserir apenas com ID e destino definidos.</div>'}</div></div><h3>Entradas registradas nesta tela</h3><div class="rel-list">${inbound.slice(0,35).map(x=>`<button data-go="${esc(x.id)}">${esc(nameOf(x.id))} → ${esc(x.r.tipo||'relação')}</button>`).join('')||'<span class="muted">Nenhuma entrada identificada neste conjunto.</span>'}</div></div><div class="rightpanel"><h3>Prévia da tela</h3><div class="preview-frame ${S.device}"><iframe class="screen-iframe" sandbox="allow-scripts" data-screen="${esc(S.screen)}" title="Prévia"></iframe></div><div class="notice">Conexões são registros semânticos; posicionar cartões não modifica rotas.</div></div></div>`}
function countPersist(){let rows=[];for(const id of screenIDs())for(const r of dt(tOf(id).dados?.persistencia))rows.push({screen:id,rec:r});return rows}
function countOps(){let rows=[];for(const id of screenIDs())for(const r of dt(tOf(id).dados?.operacoes))rows.push({screen:id,rec:r});return rows}
function visualFields(){return screenIDs().flatMap(id=>dt(tOf(id).dados?.camposDeInterface).map(x=>({id,field:x}))) }
function bankView(){const bf=S.bankView||'campos';const fields=visualFields();let body='';
 if(bf==='campos')body=`<div class="toolbar"><label>Filtrar telas <input id="bankSearch" placeholder="ID, campo ou perfil" value="${esc(S.query)}"></label><span class="count">${fields.length} campos visuais documentados</span><button data-action="mapField">Vincular campo a entidade</button></div><div class="notice">Os campos abaixo foram identificados em formulários do Protótipo. Eles não equivalem automaticamente a colunas de banco.</div><div class="table-wrap"><table><thead><tr><th>Tela</th><th>Campo visual</th><th>Tipo</th><th>Obrigatório na UI</th><th>Persistência</th></tr></thead><tbody>${fields.filter(x=>!S.query||(`${x.id} ${x.field.elementoHTMLRef}`).toLowerCase().includes(S.query.toLowerCase())).slice(0,300).map(x=>`<tr><td><button class="cell-link" data-go="${esc(x.id)}">${esc(x.id)}</button></td><td>${esc(x.field.elementoHTMLRef)}</td><td>${esc(x.field.tipoVisual)}</td><td>${x.field.obrigatorioVisual?'Sim':'—'}</td><td><span class="status-pending">A mapear</span></td></tr>`).join('')}</tbody></table></div>`;
 else if(bf==='tabelas'){const rows=countPersist();body=`<div class="toolbar"><span>${rows.length} declarações explícitas de persistência</span><button data-action="mapField">+ Declarar mapeamento</button></div>${rows.length?`<div class="table-wrap"><table><thead><tr><th>Tela</th><th>Entidade</th><th>Campo</th><th>Definição</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${esc(x.screen)}</td><td>${esc(x.rec.entidadeRef||'não declarada')}</td><td>${esc(x.rec.campoRef||'não declarado')}</td><td><code>${esc(JSON.stringify(x.rec).slice(0,220))}</code></td></tr>`).join('')}</tbody></table></div>`:`<div class="empty"><b>Nenhuma tabela homologada</b><p>A biblioteca não possui ainda mapeamentos persistentes. Identifique entidades, campos e operações por tela antes de desenhar um DER como fato.</p><button data-action="mapField">Declarar primeiro campo</button></div>`}`}
 else{const rows=countOps();body=`<div class="toolbar"><span>${rows.length} operações documentadas</span><button data-action="newOperation">+ Declarar operação</button></div>${rows.length?`<div class="table-wrap"><table><thead><tr><th>Tela</th><th>Operação</th><th>Definição</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${esc(x.screen)}</td><td>${esc(x.rec.id||'')}</td><td><code>${esc(JSON.stringify(x.rec).slice(0,220))}</code></td></tr>`).join('')}</tbody></table></div>`:`<div class="empty"><b>Nenhuma operação declarada</b><p>Escolher leitura, gravação ou chamada de função exige uma decisão vinculada à tela. Nada será inferido pelo rótulo de botões.</p></div>`}`}
 return `<div class="subnav"><button data-nav="banco:campos" class="${bf==='campos'?'selected':''}">Campos por tela</button><button data-nav="banco:tabelas" class="${bf==='tabelas'?'selected':''}">Entidades / tabelas</button><button data-nav="banco:operacoes" class="${bf==='operacoes'?'selected':''}">Operações</button></div>${body}`}
function selectedScenario(){const all=S.bundle?.simulacoes?.cenarios||{};return all[S.scenario]||all[Object.keys(all)[0]]||{}}
function rotes(){return dt(S.bundle?.simulacoes?.jornadasSimuladas)}
function flattenRoteiro(list,choices=S.branchChoices){let out=[];for(const x of dt(list)){
 if(typeof x==='string')out.push({id:x});else if(x&&typeof x==='object'){
  if(x.screen)out.push({id:x.screen,fork:x.fork,question:x.question,choices:x.choices||[],effect:x.effect});
  if(!x.fork)out.push(...flattenRoteiro(x.steps,choices));
  else{const idx=choices[x.fork];if(Number.isInteger(idx)){const ch=x.choices?.[idx];if(ch)out.push(...flattenRoteiro(ch.steps,choices))}}
 }}return out}
function prototypeView(){const scenarios=S.bundle?.simulacoes?.cenarios||{},scenarioIds=Object.keys(scenarios),scripted=S.mode.startsWith('roteiro:');let r=rotes().find(x=>x.id===S.roteiro)||rotes()[0];if(r&&!S.roteiro)S.roteiro=r.id;
 let steps=scripted&&r?flattenRoteiro(r.steps):[];S.step=Math.max(0,Math.min(S.step,Math.max(steps.length-1,0)));
 if(scripted&&steps[S.step]?.id)S.screen=steps[S.step].id;
 else if(!S.screen)S.screen=selectedScenario().start||screenIDs()[0];
 const ss=selectedScenario();const active=scripted?steps[S.step]:null;
 const screen=S.screen;
 const links=getRels(screen).filter(x=>relType(x)==='tela' && scr()[relTarget(x)]);
 return `<div class="toolbar"><div class="segmented"><button data-nav="proto:livre" class="${!scripted?'selected':''}">Navegação livre</button><button data-nav="proto:roteiros" class="${scripted?'selected':''}">Apresentação de jornadas</button></div><label>Mock <select id="scenarioSelect">${scenarioIds.map(id=>`<option value="${esc(id)}" ${id===S.scenario?'selected':''}>${esc(scenarios[id].name||id)}</option>`).join('')}</select></label><label>Dispositivo <select id="deviceSelect"><option value="mobile" ${S.device==='mobile'?'selected':''}>Mobile</option><option value="desktop" ${S.device==='desktop'?'selected':''}>Desktop</option></select></label><button data-action="resetMock">Reiniciar sessão</button></div>${scripted?`<div class="toolbar"><label>Roteiro <select id="roteiroSelect">${rotes().map(x=>`<option value="${esc(x.id)}" ${x.id===S.roteiro?'selected':''}>${esc(x.name)}</option>`).join('')}</select></label><span class="count">Etapa ${S.step+1} de ${steps.length}</span><button data-action="prevStep" ${S.step<1?'disabled':''}>← Anterior</button><button data-action="nextStep" ${S.step>=steps.length-1?'disabled':''}>Próxima →</button></div>`:`<div class="toolbar"><label>Selecionar tela ${screensSelect(screen)}</label><span class="count">Ações simuladas: ${links.length}</span></div>`}<div class="split prototype-split"><div class="center-col"><div class="prototype-heading"><strong>${esc(nameOf(screen))}</strong><code>${esc(screen)}</code></div><div class="preview-frame prototype-frame ${S.device}"><iframe class="screen-iframe" sandbox="allow-scripts" data-screen="${esc(screen)}" data-interactive="1" title="Protótipo interativo"></iframe></div><div class="actions-bar"><button data-action="protoBack">← Voltar</button>${links.map(rel=>`<button data-go="${esc(relTarget(rel))}">${esc(rel.rotulo||rel.opcao||nameOf(relTarget(rel)))}</button>`).join('')||'<span class="muted">Sem saída declarada nesta tela</span>'}</div></div><div class="rightpanel"><h3>Contexto simulado</h3><p class="mini">${esc(ss.description||'Dados fictícios de apresentação, nunca produção.')}</p><div class="facts"><div><b>Cenário</b><span>${esc(ss.name||S.scenario||'—')}</span></div><div><b>Estado da OAB (mock)</b><span>${esc(ss.status||'—')}</span></div><div><b>Cadastro</b><span>${ss.registered?'Simulado: concluído':'Simulado: pendente'}</span></div><div><b>Escritório</b><span>${ss.office?'Simulado: vinculado':'Sem vínculo simulado'}</span></div></div>${active?.fork?`<div class="fork"><b>${esc(active.question||'Escolha uma alternativa')}</b>${dt(active.choices).map((c,i)=>`<button data-choice="${esc(active.fork)}:${i}" class="${S.branchChoices[active.fork]===i?'selected':''}">${esc(c.label||'Alternativa '+(i+1))}</button>`).join('')}</div>`:''}<h3>Dados do mock</h3><details><summary>Inspecionar amostra</summary><pre>${esc(JSON.stringify(ss.data||{},null,2))}</pre></details><p class="notice">Sem chamadas HTTP, pagamentos ou gravações reais. Interações não documentadas não geram destinos.</p></div></div>`;
}
 function treeHtml(obj){
  const comp=obj?.componentes||{}, tela=obj?.tela||{};
  const refs=tela.componentes?.instanciasRefs||{};
  const placements=tela.estrutura?.html?.composicao||{};
  const nodes=new Map(),rootByComponent=new Map(),rootByInstance=new Map();
  for(const [cid,c] of Object.entries(comp)){
   const html=c?.estrutura?.html||{},elementos=html.elementos||{};
   if(!html.raizRef||!elementos[html.raizRef])continue;
   rootByComponent.set(cid,html.raizRef);
   for(const [eid,node] of Object.entries(elementos)){
    if(nodes.has(eid)){console.warn('ID visual duplicado:',eid);continue;}
    nodes.set(eid,{...node,atributos:{...(node.atributos||{})}});
   }
  }
  // As instâncias declaram qual componente usar; composição declara onde inserir.
  // Nunca deduzir hierarquia pela ordem do mapa de componentes.
  for(const [inst,cid] of Object.entries(refs)){
   const root=rootByComponent.get(cid),placement=placements[inst];
   if(!root)continue;
   rootByInstance.set(inst,root);
   if(placement){
    const node=nodes.get(root);
    if(node){node.paiRef=placement.paiRef||null;node.ordem=placement.ordem??node.ordem??0;}
   }
  }
  const children=new Map();
  for(const [id,n] of nodes){
   const parent=n.paiRef;
   if(parent&&nodes.has(parent)){
    if(!children.has(parent))children.set(parent,[]);
    children.get(parent).push(id);
   }
  }
  for(const ids of children.values())ids.sort((a,b)=>(nodes.get(a).ordem??0)-(nodes.get(b).ordem??0));
  const seen=new Set(),voids=new Set(['img','input','br','hr','source','area','wbr','col','embed']);
  const forbidden=new Set(['script','iframe','object','embed','link','meta','style','base','form']);
  function rec(id,depth=0){
   if(depth>110||seen.has(id))return '';
   seen.add(id);const n=nodes.get(id);if(!n)return '';
   if(n.tag==='#text')return esc(n.texto||'');
   if(n.tag==='#comment')return '';
   let tag=String(n.tag||'div').toLowerCase();
   if(!/^[a-z][a-z0-9-]*$/.test(tag)||forbidden.has(tag))tag='div';
   let attrs='';
   for(const [k,v] of Object.entries(n.atributos||{})){
    if(!/^[a-zA-Z_:][\w:.-]*$/.test(k)||/^on/i.test(k)||['srcdoc'].includes(k.toLowerCase()))continue;
    if(['href','src','xlink:href','action'].includes(k.toLowerCase())&&/^\s*(javascript|https?|file|blob):/i.test(String(v)))continue;
    if(typeof v!=='string'&&typeof v!=='number'&&typeof v!=='boolean')continue;
    attrs+=` ${k}="${esc(v)}"`;
   }
   const content=esc(n.texto||'')+(children.get(id)||[]).map(child=>rec(child,depth+1)).join('');
   return voids.has(tag)?`<${tag}${attrs}>`:`<${tag}${attrs}>${content}</${tag}>`;
  }
  const preferred=rootByInstance.get(tela.estrutura?.html?.raizRef)||'';
  const detached=[...nodes.keys()].filter(id=>!nodes.get(id).paiRef||!nodes.has(nodes.get(id).paiRef));
  const first=preferred&&nodes.has(preferred)?[preferred]:[];
  const roots=[...new Set([...first,...detached])];
  return roots.map(id=>rec(id)).join('');
 }
const memo=new Map();function frameDoc(id,interactive){let key=id+':'+Number(interactive);if(memo.has(key))return memo.get(key);const obj=scr()[id];if(!obj)return '<p>Tela inexistente</p>';
 let html=treeHtml(obj),parts=[];const t=obj.tela||{};for(const v of Object.values(t.estrutura?.css?.regras||{}))if(typeof v==='string')parts.push(v);
 for(const c of Object.values(obj.componentes||{}))for(let rule of Object.values(c.estrutura?.css?.regras||{}))if(typeof rule==='string')parts.push(rule.replace(/:host\b/g,'html'));
 const tokens=Object.entries(t.estrutura?.css?.tokens||{}).map(([k,v])=>`${k}:${v};`).join('');
 const addon=`<script>(function(){document.addEventListener('click',function(e){var el=e.target.closest('a,button,[data-action],[data-goto]');if(!el)return;var target=el.getAttribute('data-goto')||'';var action=el.getAttribute('data-action')||'';if(action.indexOf('navegar.')===0)target=action.slice(8);if(el.tagName==='A')e.preventDefault();if(${interactive?'true':'false'} && target){window.parent.postMessage({type:'aj.simulacao.navegar',id:target},'*')}else if(${interactive?'true':'false'} && action){window.parent.postMessage({type:'aj.simulacao.acao',action:action},'*')}});})();<\/script>`;
 const doc=`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>:root{${tokens}}html,body{margin:0;min-height:100%;background:#fff}*{box-sizing:border-box}${parts.join('\n')}</style></head><body>${html||'<p style="padding:16px">Tela sem composição visual disponível.</p>'}${addon}</body></html>`;memo.set(key,doc);return doc}
function injectFrames(pane){for(const f of pane.querySelectorAll('iframe[data-screen]')){f.srcdoc=frameDoc(f.dataset.screen,f.dataset.interactive==='1')}}
function modal(title,body){S.modal=true;let elm=$('#dialogOverlay');if(!elm){elm=make('div','modal-cover');elm.id='dialogOverlay';document.body.appendChild(elm)}elm.innerHTML=`<div class="modal"><div class="modal-head"><b>${esc(title)}</b><button data-action="closeModal" aria-label="Fechar">×</button></div><div class="modal-body">${body}</div></div>`;elm.style.display='flex';injectFrames(elm)}
function closeModal(){const m=$('#dialogOverlay');if(m)m.style.display='none';S.modal=false}
function preview(id){if(!scr()[id])return;S.screen=id;modal(nameOf(id),`<div class="preview-modal"><div class="preview-frame ${S.device}"><iframe class="screen-iframe" sandbox="allow-scripts" data-screen="${esc(id)}" title="Tela selecionada"></iframe></div><div class="modal-meta"><code>${esc(id)}</code><h3>Classificação</h3><pre>${esc(JSON.stringify(tOf(id).classificacao||{},null,2))}</pre><h3>Relações</h3><pre>${esc(JSON.stringify(getRels(id),null,2))}</pre><button data-action="showJson">Ver JSON integral</button></div></div>`)}
function showJson(){const id=S.screen||screenIDs()[0];modal('Contrato JSON · '+id,`<div class="modal-actions"><button data-action="copyScreen">Copiar JSON</button><button data-action="exportScreen">Exportar somente esta tela</button></div><pre class="bigjson">${esc(JSON.stringify(scr()[id],null,2))}</pre>`)}
function download(obj,name){const blob=new Blob([JSON.stringify(obj,null,2)+'\n'],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500)}
function touch(){S.changes++;$('#saveStatus')&&($('#saveStatus').textContent='Alterações não exportadas');memo.clear();publishJornadas()}
function askRelation(){modal('Adicionar relação explícita',`<form id="relationForm" class="form"><label>ID da relação <input name="id" required placeholder="relacao.advogado.home.destino"></label><label>Origem ${screensSelect(S.screen,'relationOrigin')}</label><label>Destino ${screensSelect('','relationDest')}</label><label>Tipo <select name="tipo"><option value="continuar">continuar</option><option value="decisao">decisao</option><option value="voltar">voltar</option></select></label><label>Condição (ID, opcional) <input name="condicao" placeholder="condicaoRef (sem inventar expressão)"></label><label>Rótulo <input name="rotulo"></label><button type="submit">Confirmar ligação no JSON local</button></form>`)}
function relationSubmit(f){const id=f.querySelector('[name="id"]').value.trim(),origin=$('#relationOrigin').value,dest=$('#relationDest').value;if(!id||!origin||!dest){alert('Preencha ID, origem e destino.');return}for(const s of screenIDs())if(getRels(s).some(r=>r.id===id)){alert('ID de relação já existe.');return}const nav=tOf(origin).navegacao;nav.relacoes||=[];nav.relacoes.push({id,tipo:f.querySelector('[name="tipo"]').value,origem:{tipo:'tela',ref:origin},destino:{tipo:'tela',ref:dest},rotulo:f.querySelector('[name="rotulo"]').value||null,condicaoRef:f.querySelector('[name="condicao"]').value||null,situacao:'declarada_pelo_editor'});touch();closeModal();S.screen=origin;shell()}
function newJourney(){modal('Nova jornada',`<form class="form" id="journeyForm"><p class="mini">Identifique a jornada explicitamente. Não geramos IDs por dedução do nome.</p><label>ID da jornada <input name="id" required placeholder="ex.: cliente"></label><label>Nome da jornada <input name="name" required></label><label>ID da primeira subjornada <input name="subid" required placeholder="ex.: cadastro"></label><label>Nome da subjornada <input name="subname" required></label><label>Tela inicial ${screensSelect(S.screen,'journeyScreen')}</label><button type="submit">Criar participação</button></form>`)}
function journeySubmit(f){const id=f.querySelector('[name="id"]').value.trim(),name=f.querySelector('[name="name"]').value.trim(),subid=f.querySelector('[name="subid"]').value.trim(),subname=f.querySelector('[name="subname"]').value.trim(),screen=$('#journeyScreen').value;if(!id||!name||!subid||!subname||!screen)return;const joins=tOf(screen).classificacao.jornadas||=[];if(joins.some(x=>x.id==='part.'+id+'.'+screen)){alert('Participação já existe.');return}joins.push({id:'part.'+id+'.'+screen,jornada:{id,nome:name,ordem:jIndex().length+1},subjornada:{id:subid,nome:subname,ordem:1},ordemTela:1,ocorrenciaNo:null,condicaoRef:null});tOf(screen).classificacao.jornadas=joins;touch();closeModal();S.journey=id;setMode('journey:'+id)}
function addToJourney(){const j=findJourney(S.journey);if(!j)return;modal('Incluir tela na jornada',`<form class="form" id="addScreenForm"><label>Tela ${screensSelect(S.screen,'addScreenId')}</label><label>Subjornada <select id="addSub">${[...j.subs.values()].map(x=>`<option value="${esc(x.id)}">${esc(x.name)}</option>`).join('')}</select></label><label>ID da participação <input name="id" required placeholder="part.${esc(j.id)}.tela"></label><label>Ordem da tela <input name="order" type="number" min="1" value="1" required></label><button type="submit">Adicionar participação</button></form>`)}
function addScreenSubmit(f){const sid=$('#addScreenId').value,j=findJourney(S.journey),sub=j.subs.get($('#addSub').value),pid=f.querySelector('[name="id"]').value.trim(),ord=+f.querySelector('[name="order"]').value;if(!sid||!pid||!sub||!ord)return;const cls=tOf(sid).classificacao;cls.jornadas||=[];if(cls.jornadas.some(p=>p.id===pid)){alert('Participação já existe.');return}cls.jornadas.push({id:pid,jornada:{id:j.id,nome:j.name,ordem:j.order},subjornada:{id:sub.id,nome:sub.name,ordem:sub.order},ordemTela:ord,ocorrenciaNo:null,condicaoRef:null});touch();closeModal();shell()}
function mapField(){modal('Declarar campo persistente',`<form id="bankForm" class="form"><p class="mini">Este mapeamento é uma decisão explícita no contrato da tela. Não transforma automaticamente outros formulários em tabelas.</p><label>Tela ${screensSelect(S.screen,'bankScreen')}</label><label>ID da declaração <input name="id" required placeholder="map.auth.usuario.email"></label><label>ID da entidade <input name="entity" required placeholder="entidade.usuario"></label><label>ID do campo persistente <input name="field" required placeholder="campo.usuario.email"></label><label>Campo visual de origem (opcional) <input name="origin" placeholder="reg-email"></label><label>Tipo lógico <select name="type"><option>texto</option><option>numero</option><option>data</option><option>booleano</option><option>objeto</option></select></label><button type="submit">Registrar no JSON local</button></form>`)}
function bankSubmit(f){const vals=Object.fromEntries(new FormData(f));if(!vals.id||!vals.entity||!vals.field)return;const screen=$('#bankScreen').value;const dat=tOf(screen).dados;dat.persistencia||=[];if(dat.persistencia.some(x=>x.id===vals.id)){alert('ID já declarado nesta tela');return}dat.persistencia.push({id:vals.id,entidadeRef:vals.entity,campoRef:vals.field,elementoHTMLRef:vals.origin||null,tipoLogico:vals.type,situacao:'declaracao_pelo_editor'});touch();closeModal();setMode('banco:tabelas')}
function newOperation(){modal('Declarar operação de dados',`<form class="form" id="operationForm"><label>Tela ${screensSelect(S.screen,'operationScreen')}</label><label>ID único <input name="id" required placeholder="op.auth.cadastro.salvar"></label><label>Tipo <select name="type"><option value="leitura">Leitura</option><option value="gravacao">Gravação</option><option value="chamada_funcao">Chamada de função</option></select></label><label>Recurso de destino (referência explícita) <input name="resource" required placeholder="entidade.usuario ou funcao.usuario.criar"></label><button type="submit">Registrar operação</button></form>`)}
function operationSubmit(f){const v=Object.fromEntries(new FormData(f));if(!v.id||!v.resource)return;const dat=tOf($('#operationScreen').value).dados;dat.operacoes||=[];if(dat.operacoes.some(x=>x.id===v.id)){alert('ID duplicado');return}dat.operacoes.push({id:v.id,tipo:v.type,recursoRef:v.resource,situacao:'declaracao_pelo_editor'});touch();closeModal();setMode('banco:operacoes')}
function handleClick(e){const a=e.target.closest('[data-action],[data-nav],[data-preview],[data-go],[data-choice]');if(!a)return;e.preventDefault();if(a.dataset.nav){setMode(a.dataset.nav);return}if(a.dataset.preview){preview(a.dataset.preview);return}if(a.dataset.go){if(!scr()[a.dataset.go])return;S.history.push(S.screen);S.screen=a.dataset.go;if(MODULO==='JORNADAS')preview(S.screen);else shell();return}if(a.dataset.choice){const [fork,raw]=a.dataset.choice.split(':');S.branchChoices[fork]=Number(raw);S.step++;shell();return}const act=a.dataset.action;if(!act)return;
 if(act==='toggleSidebar'){$('#sidebar')?.classList.toggle('open');return}
 if(act==='import'){$('#fileLoader')?.click();return}
 if(act==='export'){download(S.bundle,'modulo_'+MODULO.toLowerCase()+'_atualizado.json');S.changes=0;$('#saveStatus')&&($('#saveStatus').textContent='Exportado nesta sessão');return}
 if(act==='closeModal'){closeModal();return}
 if(act==='showJson'){showJson();return}
 if(act==='copyScreen'){navigator.clipboard?.writeText(JSON.stringify(current(),null,2));return}
 if(act==='exportScreen'){download({[S.screen]:current()},S.screen+'.json');return}
 if(act==='addRelation'){askRelation();return}
 if(act==='moreScreens'){S.showCount+=24;renderPane();return}
 if(act==='newJourney'){newJourney();return}
 if(act==='addToJourney'){addToJourney();return}
 if(act==='mapField'){mapField();return}
 if(act==='newOperation'){newOperation();return}
 if(act==='prevStep'){S.step=Math.max(0,S.step-1);shell();return}
 if(act==='nextStep'){S.step++;shell();return}
 if(act==='protoBack'){S.screen=S.history.pop()||S.screen;shell();return}
 if(act==='resetMock'){S.history=[];S.screen=selectedScenario().start||screenIDs()[0];S.step=0;S.branchChoices={};shell();return}
}
function handleChange(e){const id=e.target.id,v=e.target.value;
 if(id==='screenSelect'){S.screen=v;renderPane()}else if(id==='journeySelect'){S.journey=v;S.subjourney=null;setMode('journey:'+v)}else if(id==='subjourneySelect'){S.subjourney=v;renderPane()}else if(id==='deviceSelect'){S.device=v;renderPane()}else if(id==='scenarioSelect'){S.scenario=v;S.screen=selectedScenario().start||S.screen;S.history=[];renderPane()}else if(id==='roteiroSelect'){S.roteiro=v;setMode('roteiro:'+v)}else if(['fieldSearch','journeySearch','bankSearch'].includes(id)){S.query=v;renderPane()}else if(id==='fileLoader'){
 const file=e.target.files?.[0];if(!file)return;file.text().then(txt=>{try{const j=JSON.parse(txt);if(!j||!j.telas||!j.modulo)throw Error('Falta o objeto telas/modulo');if(j.modulo.toUpperCase()!==MODULO)throw Error('JSON de outro módulo: '+j.modulo);S.bundle=j;S.screen=j.telas['auth.inicializacao.splash']?'auth.inicializacao.splash':Object.keys(j.telas)[0];S.changes=0;memo.clear();shell()}catch(err){alert('Arquivo inválido: '+err.message)}});e.target.value='';}
}
function handleSubmit(e){if(!['relationForm','journeyForm','addScreenForm','bankForm','operationForm'].includes(e.target.id))return;e.preventDefault();({relationForm:relationSubmit,journeyForm:journeySubmit,addScreenForm:addScreenSubmit,bankForm:bankSubmit,operationForm:operationSubmit})[e.target.id](e.target)}
window.addEventListener('message',e=>{if(!S.bundle||MODULO!=='PROTOTIPO')return;const data=e.data;if(data?.type==='aj.simulacao.navegar'&&typeof data.id==='string'){const id=data.id;if(!scr()[id])return;const possible=getRels(S.screen).some(r=>relTarget(r)===id&&relType(r)==='tela');if(!possible){alert('Destino não documentado como relação da tela atual.');return}S.history.push(S.screen);S.screen=id;shell()}else if(data?.type==='aj.simulacao.acao'){const msg='Evento local documentado: '+data.action+' · Sem efeito externo.';$('#saveStatus')&&($('#saveStatus').textContent=msg.slice(0,70))}});
// Integração opcional apenas com o index do módulo; cada pasta continua autônoma.
function publishJornadas(){
 if(!S.bundle||window.parent===window)return;
 const journeys=jIndex().map(j=>({id:j.id,name:j.name,count:[...j.subs.values()].reduce((sum,s)=>sum+s.items.length,0)}));
 window.parent.postMessage({type:'aj.jornadas.estado',submodulo:SUBMODULO,jornadas:SUBMODULO==='APRESENTACOES'?journeys:[],telas:screenIDs().length,alteracoes:S.changes,modo:S.mode},'*');
}
window.addEventListener('message',e=>{
 if(e.source!==window.parent||!S.bundle||!e.data||typeof e.data!=='object')return;
 const msg=e.data;
 if(msg.type==='aj.jornadas.selecionar'&&SUBMODULO==='APRESENTACOES'){
   if(!jIndex().some(j=>j.id===msg.id))return;
   setMode('journey:'+msg.id);
 }else if(msg.type==='aj.jornadas.exportar'){
   window.parent.postMessage({type:'aj.jornadas.arquivo',submodulo:SUBMODULO,nome:'jornadas_'+SUBMODULO.toLowerCase()+'_documento.json',conteudo:JSON.stringify(S.bundle,null,2)+'\n'},'*');
   S.changes=0;publishJornadas();
 }else if(msg.type==='aj.jornadas.importar'){
   try{
     const j=JSON.parse(msg.conteudo);
     if(j?.modulo?.toUpperCase()!==MODULO||!j.telas||typeof j.telas!=='object')throw Error('JSON de módulo incompatível');
     S.bundle=j;S.screen=j.telas['auth.inicializacao.splash']?'auth.inicializacao.splash':Object.keys(j.telas)[0];
     S.changes=0;S.query='';S.journey=null;S.subjourney=null;memo.clear();
     S.mode=SUBMODULO==='CAMPOS'?'campos':'journey:'+(jIndex()[0]?.id||'');
     shell();
     window.parent.postMessage({type:'aj.jornadas.importado',submodulo:SUBMODULO},'*');
   }catch(err){window.parent.postMessage({type:'aj.jornadas.erro',mensagem:err.message},'*');}
 }
});

// API mínima para o index escolher telas sem reproduzir os motores dos módulos.
window.AJWorkspace={navigate(mode){if(!S.bundle)return false;setMode(mode);return true},getMode(){return S.mode}};
document.addEventListener('click',handleClick);document.addEventListener('change',handleChange);document.addEventListener('submit',handleSubmit);
async function start(){try{const response=await fetch('./documento.json',{cache:'no-store'});if(!response.ok)throw Error('HTTP '+response.status);const j=await response.json();if(j.modulo?.toUpperCase()!==MODULO)throw Error('módulo incompatível');S.bundle=j;S.screen=j.telas['auth.inicializacao.splash']?'auth.inicializacao.splash':Object.keys(j.telas)[0];S.scenario=Object.keys(j.simulacoes?.cenarios||{})[0]||null;S.mode=SUBMODULO==='CAMPOS'?'campos':MODULO==='JORNADAS'?'journey:'+(jIndex()[0]?.id||''):MODULO==='PROTOTIPO'?'proto:livre':MODULO==='BANCO'?'banco:campos':'visualizacao';if(MODULO==='BANCO')S.bankView='campos';shell()}catch(err){app.innerHTML=`<div class="loader-error"><div class="brand-mark">AJ</div><h1>Carregar módulo ${esc(moduleName())}</h1><p>Este módulo não busca dados fora de sua pasta. Para abrir o <code>index.html</code> diretamente como arquivo local, selecione seu próprio <code>documento.json</code>. Em servidor estático local, a leitura é automática.</p><input id="fallbackFile" type="file" accept=".json,application/json"><p class="mini">Detalhe técnico: ${esc(err.message)}</p></div>`;$('#fallbackFile').onchange=async e=>{try{const j=JSON.parse(await e.target.files[0].text());if(j.modulo?.toUpperCase()!==MODULO||!j.telas)throw Error('JSON incorreto');S.bundle=j;S.screen=j.telas['auth.inicializacao.splash']?'auth.inicializacao.splash':Object.keys(j.telas)[0];S.scenario=Object.keys(j.simulacoes?.cenarios||{})[0]||null;S.mode=SUBMODULO==='CAMPOS'?'campos':MODULO==='JORNADAS'?'journey:'+(jIndex()[0]?.id||''):MODULO==='PROTOTIPO'?'proto:livre':MODULO==='BANCO'?'banco:campos':'visualizacao';if(MODULO==='BANCO')S.bankView='campos';shell()}catch(ex){alert(ex.message)}};}}
start();
})();

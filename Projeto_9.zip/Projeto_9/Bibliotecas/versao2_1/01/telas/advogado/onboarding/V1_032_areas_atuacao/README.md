# advogado.onboarding.areas_atuacao — Biblioteca 2.1

- Origem informacional: `01/telas/advogado/onboarding/V1_032_areas_atuacao/documento.json`
- Molde: `versao3` (contrato e motor).
- Componentes agora em `componentes/catalogo.json`, por IDs explícitos.
- Rotas com `eventoRef: null` são pendências não executáveis; confirmar contra as jornadas e origens.
- Este pacote não declara equivalência visual ou funcional integral homologada.
- Evento identificado por destino explícito: 2. Eventos pendentes: 0.
